/**
 * Demonstration.java
 * Egy felvonulás (demonstráció) adatait reprezentáló modell osztály.
 * Tárolja az azonosítót, nevet, dátumot, létszámot, pártot és vezető nevét.
 */
public class Demonstration {

    // A felvonulás egyedi azonosítója
    private int id;

    // A felvonulás neve
    private String name;

    // A felvonulás dátuma (pl. "2026-03-15")
    private String date;

    // A résztvevők száma
    private int count;

    // A szervező párt neve
    private String party;

    // A vezető neve
    private String leaderName;

    /**
     * Konstruktor: beállítja az összes mezőt
     */
    public Demonstration(int id, String name, String date, int count, String party, String leaderName) {
        this.id = id;
        this.name = name;
        this.date = date;
        this.count = count;
        this.party = party;
        this.leaderName = leaderName;
    }

    // --- Getterek ---

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDate() { return date; }
    public int getCount() { return count; }
    public String getParty() { return party; }
    public String getLeaderName() { return leaderName; }

    /**
     * Megadja, hogy a dátum melyik évben van (pl. "2026-03-15" → 2026)
     */
    public int getYear() {
        return Integer.parseInt(date.split("-")[0]);
    }

    /**
     * toString: a feladatlap mintájának megfelelő formátumban adja vissza az adatokat
     */
    @Override
    public String toString() {
        return "Azonosító: " + id + "\n" +
                "Név: " + name + "\n" +
                "Dátum: " + date + "\n" +
                "Létszám: " + count + "\n" +
                "Párt: " + party + "\n" +
                "Vezető: " + leaderName;
    }
}