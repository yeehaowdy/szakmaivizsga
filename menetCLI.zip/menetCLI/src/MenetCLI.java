import java.io.*;
import java.util.*;
import java.util.stream.*;

/**
 * MenetCLI.java
 * Konzolos alkalmazás a felvonulasok.csv fájl feldolgozásához.
 * Megoldja a feladatlap összes CLI feladatát (1–7).
 *
 * A CSV fájl szerkezete (pontosvessző elválasztóval):
 *   demonstration_id ; demonstration_name ; date ; count ; party ; leader_name ; attendant_name
 *
 * Futtatás: java MenetCLI felvonulasok.csv
 */
public class MenetCLI {

    public static void main(String[] args) throws IOException {

        // A CSV fájl elérési útja (parancssori argumentumból, vagy alapértelmezett)
        String csvPath = args.length > 0 ? args[0] : "felvonulasok.csv";

        // -------------------------------------------------------
        // Adatok beolvasása
        // -------------------------------------------------------

        // Nyers sorok listája (minden CSV-sor egy elem)
        List<String[]> sorok = new ArrayList<>();

        // Demonstrációk egyedi listája (id → Demonstration)
        Map<Integer, Demonstration> demonstracioMap = new LinkedHashMap<>();

        // Résztvevők → demonstráció-lista (ki melyikeken vett részt)
        // Kulcs: résztvevő neve, Érték: azon demonstrációk listája, ahol szerepel
        Map<String, List<Demonstration>> resztvevoMap = new LinkedHashMap<>();

        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new FileInputStream(csvPath), "UTF-8"))) {

            String sor;
            boolean elsoSor = true;

            while ((sor = br.readLine()) != null) {
                // Üres sorokat kihagyjuk
                if (sor.trim().isEmpty()) continue;

                // Ha az első sor fejléc (betűvel kezdődik), kihagyjuk
                if (elsoSor) {
                    elsoSor = false;
                    // Ha az első mező nem szám → fejléc, kihagyjuk
                    String[] mezok = sor.split(";", -1);
                    try {
                        Integer.parseInt(mezok[0].trim());
                    } catch (NumberFormatException e) {
                        continue; // fejléc sor → kihagyjuk
                    }
                }

                // Vesszük a sor mezőit
                String[] mezok = sor.split(";", -1);
                if (mezok.length < 7) continue;

                sorok.add(mezok);

                // Mezők kinyerése
                int demoId       = Integer.parseInt(mezok[0].trim());
                String demoNev   = mezok[1].trim();
                String datum     = mezok[2].trim();
                int letszam      = Integer.parseInt(mezok[3].trim());
                String part      = mezok[4].trim();
                String vezeto    = mezok[5].trim();
                String resztvevo = mezok[6].trim();

                // Ha ez az azonosító még nem szerepel, felvesszük a demonstráció-térképbe
                if (!demonstracioMap.containsKey(demoId)) {
                    demonstracioMap.put(demoId,
                            new Demonstration(demoId, demoNev, datum, letszam, part, vezeto));
                }

                // A résztvevőhöz hozzáadjuk a demonstrációt (ha még nem szerepel nála)
                Demonstration demo = demonstracioMap.get(demoId);
                resztvevoMap.computeIfAbsent(resztvevo, k -> new ArrayList<>());
                // Csak akkor adjuk hozzá, ha ez a demo még nincs a listájában
                boolean marBenne = resztvevoMap.get(resztvevo).stream()
                        .anyMatch(d -> d.getId() == demoId);
                if (!marBenne) {
                    resztvevoMap.get(resztvevo).add(demo);
                }
            }
        }

        // Demonstrációk listája (egyedi, beolvasás sorrendjében)
        List<Demonstration> demonstraciok = new ArrayList<>(demonstracioMap.values());

        // -------------------------------------------------------
        // 1. feladat: Beolvasott sorok száma
        // -------------------------------------------------------
        System.out.println("1. feladat");
        System.out.println("Beolvasott sorok száma: " + sorok.size());
        System.out.println();

        // -------------------------------------------------------
        // 2. feladat: Legnagyobb létszámú demonstráció
        // -------------------------------------------------------
        System.out.println("2. feladat");
        System.out.println("Legnagyobb létszámú demonstráció:");

        // Megkeressük a max count értékű demonstrációt
        Demonstration legnagyobb = demonstraciok.stream()
                .max(Comparator.comparingInt(Demonstration::getCount))
                .orElse(null);

        if (legnagyobb != null) {
            System.out.println(legnagyobb); // toString() hívás
        }
        System.out.println();

        // -------------------------------------------------------
        // 3. feladat: 2026-ban kezdődő demonstrációk, létszám szerint csökkenő sorrendben
        // -------------------------------------------------------
        System.out.println("3. feladat");
        System.out.println("2026-ban kezdődő demonstrációk:");

        // Szűrés évre, majd rendezés létszám szerint csökkenően
        demonstraciok.stream()
                .filter(d -> d.getYear() == 2026)
                .sorted(Comparator.comparingInt(Demonstration::getCount).reversed())
                .forEach(d -> System.out.println(d.getName() + " - " + d.getCount() + " fő"));
        System.out.println();

        // -------------------------------------------------------
        // 4. feladat: Egyedi résztvevők, véletlenszerű választás
        // -------------------------------------------------------
        System.out.println("4. feladat");

        // Egyedi résztvevők száma = a resztvevoMap kulcsainak száma
        int egyediResztvevok = resztvevoMap.size();
        System.out.println("Egyedi résztvevők száma: " + egyediResztvevok);

        // Véletlenszerű választás a résztvevők listájából
        List<String> resztvevoNevek = new ArrayList<>(resztvevoMap.keySet());
        Random random = new Random();
        String valasztott = resztvevoNevek.get(random.nextInt(resztvevoNevek.size()));
        System.out.println("Véletlenszerűen választott résztvevő: " + valasztott);

        // Kiírjuk, hogy a választott résztvevő melyik demonstrációkon szerepelt
        System.out.println("A választott résztvevő demonstrációi:");
        for (Demonstration d : resztvevoMap.get(valasztott)) {
            System.out.println("- " + d.getName() + " (" + d.getDate() + ")");
        }
        System.out.println();

        // -------------------------------------------------------
        // 5. feladat: Szószám függvény + legtöbb szóból álló demonstrációnév
        // -------------------------------------------------------
        System.out.println("5. feladat");
        System.out.println("Demonstráció nevének szószáma:");

        // Megkeressük a legtöbb szóból álló nevet
        Demonstration leghosszabb = demonstraciok.stream()
                .max(Comparator.comparingInt(d -> szoszam(d.getName())))
                .orElse(null);

        // Pár példa kiíratása (az összes demonstráció nevét és szószámát)
        for (Demonstration d : demonstraciok) {
            System.out.println(d.getName() + " -> " + szoszam(d.getName()) + " szó");
        }

        System.out.println();
        System.out.println("Leghosszabb demonstrációnév:");
        if (leghosszabb != null) {
            System.out.println(leghosszabb.getName() +
                    " (" + szoszam(leghosszabb.getName()) + " szó)");
        }
        System.out.println();

        // -------------------------------------------------------
        // 6. feladat: Statisztika éves bontásban, növekvő évszám szerint
        // -------------------------------------------------------
        System.out.println("6. feladat");
        System.out.println("Demonstrációk száma éves bontásban:");

        // Csoportosítás év szerint, majd rendezés
        Map<Integer, Long> evesBontas = demonstraciok.stream()
                .collect(Collectors.groupingBy(
                        Demonstration::getYear,
                        TreeMap::new,         // TreeMap: automatikusan rendez kulcs szerint
                        Collectors.counting()
                ));

        // Kiírás vesszővel, utolsó után NEM kerül vessző
        List<Map.Entry<Integer, Long>> bejeglzesek = new ArrayList<>(evesBontas.entrySet());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < bejeglzesek.size(); i++) {
            Map.Entry<Integer, Long> entry = bejeglzesek.get(i);
            sb.append(entry.getKey()).append(": ").append(entry.getValue());
            if (i < bejeglzesek.size() - 1) {
                sb.append(", "); // vesszőt csak NEM az utolsó után teszünk
            }
        }
        System.out.println(sb.toString());
        System.out.println();

        // -------------------------------------------------------
        // 7. feladat: Legfeljebb 100 fős demonstrációk mentése rovidek.txt-be
        // -------------------------------------------------------
        System.out.println("7. feladat");

        // Szűrés: count <= 100
        List<Demonstration> rovidek = demonstraciok.stream()
                .filter(d -> d.getCount() <= 100)
                .collect(Collectors.toList());

        // Fájlba írás
        try (PrintWriter pw = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream("rovidek.txt"), "UTF-8"))) {

            for (Demonstration d : rovidek) {
                // A minta szerint: "NÉV (LÉTSZÁM fő)"
                pw.println(d.getName() + " (" + d.getCount() + " fő)");
            }
        }

        System.out.println("A legfeljebb 100 fős demonstrációk adatai elmentve a rovidek.txt fájlba.");
        System.out.println("Mentett elemek száma: " + rovidek.size());

        // A mentett elemek listázása
        for (Demonstration d : rovidek) {
            System.out.println("- " + d.getName() + " (" + d.getCount() + " fő)");
        }

        System.out.println();
        System.out.println("Program vége.");
    }

    /**
     * Megadja, hogy a paraméterben kapott demonstráció neve hány szóból áll.
     * Szóhatár: szóköz karakter.
     *
     * @param nev a demonstráció neve
     * @return a szavak száma
     */
    public static int szoszam(String nev) {
        if (nev == null || nev.trim().isEmpty()) return 0;
        // Feldaraboljuk szóközök mentén (egymás melletti szóközöket is kezeli)
        return nev.trim().split("\\s+").length;
    }
}