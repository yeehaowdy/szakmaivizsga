import express from 'express'
import cors from 'cors'
import mysql from 'mysql2'

const app = express();
app.use(express.json());
app.use(cors());

const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'propaganda'
});

app.get('/api/streets', (req, res)=>{
    const sql = 'SELECT * FROM utcak ORDER BY nev ASC;'
    conn.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
})

app.get('/api/plakatok/by-lat/:lat/by-long/:long', (req, res)=>{
    const {lat, long} = req.params
    const sql = 'SELECT * FROM `plakatok` INNER JOIN kihelyezesek ON plakatok.id = kihelyezesek.plakat_id WHERE ABS(kihelyezesek.szelessegi - ?) <0.1  AND ABS(kihelyezesek.hosszusagi - ?) <0.1;'
    conn.query(sql, [lat, long], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
})

app.get('/api/by-search/:search_word', (req, res)=>{
    const word = `${req.params.search_word}`
    const sql = 'SELECT * FROM plakatok JOIN kihelyezesek ON plakatok.id = kihelyezesek.plakat_id JOIN utcak ON kihelyezesek.szelessegi = utcak.szelessegi AND kihelyezesek.hosszusagi = utcak.hosszusagi WHERE plakatok.part LIKE ? OR utcak.varos LIKE ? OR utcak.nev LIKE ?';
    conn.query(sql, [word, word, word], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
})

app.get('/api/kihelyezesek', (req, res)=>{
    const sql = 'SELECT * FROM utcak INNER JOIN kihelyezesek ON utcak.szelessegi = kihelyezesek.szelessegi AND kihelyezesek.hosszusagi = utcak.hosszusagi INNER JOIN plakatok ON kihelyezesek.plakat_id = plakatok.id';
    conn.query(sql, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results);
    });
})

app.post('/api/kihelyezes', (req, res)=>{
    const {szelessegi, hosszusagi, plakat_id} = req.body;
    const sql = "INSERT INTO kihelyzesek (szelessegi, hosszusagi, plakat_id) VALUES (?, ?, ?)";
    conn.query(sql, [szelessegi, hosszusagi, plakat_id], (err, results)=>{
        if(err){
            console.error(err)
            return res.status(500)
            res.json({message: "", id: results.insertId})
        }
    })
})

app.listen(3333, () => console.log('Szerver fut: port:3333'));