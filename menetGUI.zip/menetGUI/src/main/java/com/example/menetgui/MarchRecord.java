package com.example.menetgui;


public class MarchRecord {
    private int id;
    private String name;
    private String date;
    private int count;
    private String party;
    private String leader;
    private String attendant;

    public MarchRecord(String line) {
        String[] parts = line.split(";");
        this.id = Integer.parseInt(parts[0]);
        this.name = parts[1];
        this.date = parts[2];
        this.count = Integer.parseInt(parts[3]);
        this.party = parts[4];
        this.leader = parts[5];
        this.attendant = parts[6];
    }

    public String getName() { return name; }
    public String getAttendant() { return attendant; }
    public String getDate() { return date; }
}
