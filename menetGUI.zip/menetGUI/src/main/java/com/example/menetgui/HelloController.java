package com.example.menetgui;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import java.io.File;
import java.nio.file.Files;
import java.util.*;
import java.util.stream.Collectors;

public class HelloController {

    @FXML private RadioButton rb1, rb2;
    @FXML private ListView<String> lv_left, lv_right;

    private List<MarchRecord> allRecords = new ArrayList<>();
    private ToggleGroup group = new ToggleGroup();

    @FXML
    public void initialize() {
        // Rádiógombok beállítása és csoportosítása
        rb1.setToggleGroup(group);
        rb2.setToggleGroup(group);
        rb1.setText("Menetek");
        rb2.setText("Felvonulók");
        rb1.setSelected(true); // Alapértelmezett kiválasztás [cite: 26]

        // Választógomb váltásakor lista frissítése
        group.selectedToggleProperty().addListener((observable, oldValue, newValue) -> updateLeftList());

        // Bal oldali lista kattintás eseménye [cite: 29, 30]
        lv_left.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                updateRightList(newValue);
            }
        });
    }

    @FXML
    protected void handleMenuOpen() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV fájlok", "*.csv"));
        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            try {
                List<String> lines = Files.readAllLines(selectedFile.toPath());
                allRecords.clear();
                // Első sor (fejléc) kihagyása [cite: 23]
                for (int i = 1; i < lines.size(); i++) {
                    allRecords.add(new MarchRecord(lines.get(i)));
                }
                updateLeftList();
            } catch (Exception e) {
                showError("Hiba a fájl beolvasásakor!");
            }
        }
    }

    private void updateLeftList() {
        if (allRecords.isEmpty()) return;

        if (rb1.isSelected()) {
            // Menetek nevei (egyedi listában) [cite: 29]
            List<String> marches = allRecords.stream()
                    .map(MarchRecord::getName)
                    .distinct()
                    .collect(Collectors.toList());
            lv_left.setItems(FXCollections.observableArrayList(marches));
        } else {
            // Felvonulók nevei ABC sorrendben [cite: 30]
            List<String> attendants = allRecords.stream()
                    .map(MarchRecord::getAttendant)
                    .distinct()
                    .sorted()
                    .collect(Collectors.toList());
            lv_left.setItems(FXCollections.observableArrayList(attendants));
        }
        lv_right.getItems().clear();
    }

    private void updateRightList(String selectedItem) {
        if (rb1.isSelected()) {
            // Egy menet résztvevői [cite: 29]
            List<String> attendants = allRecords.stream()
                    .filter(r -> r.getName().equals(selectedItem))
                    .map(MarchRecord::getAttendant)
                    .collect(Collectors.toList());
            lv_right.setItems(FXCollections.observableArrayList(attendants));
        } else {
            // Egy résztvevő menetei [cite: 30]
            List<String> marches = allRecords.stream()
                    .filter(r -> r.getAttendant().equals(selectedItem))
                    .map(r -> r.getName() + " (" + r.getDate() + ")")
                    .collect(Collectors.toList());
            lv_right.setItems(FXCollections.observableArrayList(marches));
        }
    }

    @FXML
    protected void onExit() {
        Platform.exit(); // Program bezárása [cite: 31]
    }

    @FXML
    protected void onAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Névjegy");
        alert.setHeaderText("MenetGUI Alkalmazás");
        alert.setContentText("Készítette: [Vizsgázó Neve]\nVerzió: 1.0");
        alert.showAndWait(); // [cite: 31]
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message);
        alert.showAndWait();
    }
}