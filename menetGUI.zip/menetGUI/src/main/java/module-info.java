module com.example.menetgui {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.menetgui to javafx.fxml;
    exports com.example.menetgui;
}